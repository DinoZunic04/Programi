#include <stdio.h>
#include <stdlib.h>
#include "olaksica.h"
int main(int argc, char const *argv[]) {
    char s[255];
    getstring(s);
    printf("%s\n%d\n",s,length(s));
    return 0;
}

#include <stdio.h>
#include <stdlib.h>
#include "olaksica.h"
int pripada(char x, char a[])
{
    int i;
    for(i=0;i<length(a);i++)
    {
        if(a[i]==x)
            return 1;
    }
    return 0;
}
int main(int argc, char const *argv[]) {
    int i,j,k;
    char s[2047],cifre[]="0123456789",operacije[]="+-/*^()";
    getstring(s);
    for(i=0;i<256;i++)
    {
        if(!(pripada(i,cifre)||pripada(i,operacije)||i=='.'))
            removeAllChar(s,i);
    }
    if(pripada(s[length(s)-1],operacije))   removeChar(s,length(s)-1);
    for(i=0;i<length(s)-1;i++)
    {
        if(pripada(s[i],operacije))
        {
            for(j=i+1;pripada(s[j],operacije)&&j<length(s);)
                removeChar(s,j);
        }
    }
    for(i=0;i<length(s)-1;i++)
    {
        if(pripada(s[i],operacije))
        {
            while(pripada(s[j],operacije)&&j<length(s))
                removeChar(s,i+1);
            if(s[i+1]=='.')  addChar(s,i+1,'0');
        }
    }
    for(i=0;i<length(s);i++)
    {
        if(pripada(s[i],cifre))
        {
            int chk=0;
            for(j=i+1;!(pripada(s[j],cifre)||s[j]=='.')||j<length(s);j++)
            {
                if(s[j]=='.')
                {
                    if(chk)
                        removeChar(s,j);
                    else
                    {
                        if(j+1<length(s)&&!(pripada(s[j],cifre)||s[j]=='.'))
                            removeChar(s,j);
                        chk=1;
                    }
                }
            }
        }
    }
    printf("%s\n",s);
    return 0;
}

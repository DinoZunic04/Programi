//string
int length(char s[])
{
    int i;
    for(i=0;s[i]!='\0';i++);
    return i;
}
void getstring(char s[])
{
    char c;
    int i=0;
    while((c=getchar())!='\n')
    {
        s[i]=c;
        i++;
    }
    s[i]='\0';
}
void removeChar(char s[],int index)
{
    int i;
    for(i=index;i<length(s)-1;i++)  s[i]=s[i+1];
    s[i]='\0';
}
void addChar(char s[],int index,char c)
{
    int i;
    for(i=length(s);i>index;i--) s[i]=s[i-1];
    s[length(s)]='\0';
    s[index]=c;
}
void removeAllChar(char s[],char c)
{
    int i;
    for(i=0;i<length(s);i++)
    {
        if(s[i]==c)
        {
            removeChar(s,i);
            i--;
        }
    }
}
